#### liberxue.github.io demo [查看](https://liberxue.github.io/)


`Jekyll Themes`
----------
  
### Jekyll轻量级极简博客

#### 第一步是点击[fork](https://github.com/Liberxue/liberxue.github.io#fork-destination-box)
##### 第二步: 修改_config.yml 中的url 为您的域名
#### OK 好了  就这么简单  
#### 我不要任何版权也不需要您在捐款，帮忙star下 一个🌟 谢谢 😄
- [x] 自动生成标签
- [x] 自动生成json搜索
- [x] 自适应模板
- [x] 自动生成feed.xml
- [x] 自动生成分页
- [x] 修改_config.yml 的links 为您的菜单
- [x] 修改_config.yml  的paginate 为您的按照多少页分页

![uiliberxue](https://raw.githubusercontent.com/Liberxue/liberxue.github.io/master/thumbnails/ui.jpg) 
 
 ----------
![博客搜索](https://raw.githubusercontent.com/Liberxue/liberxue.github.io/master/thumbnails/01.gif) 

轻量级 最小blog 
第一步: 点击[fork](https://github.com/Liberxue/liberxue.github.io#fork-destination-box)
 
----

![fork操作](https://raw.githubusercontent.com/Liberxue/liberxue.github.io/master/thumbnails/02.gif)
  
  


第二步: 修改_config.yml 中的url 为您的域名

![修改_config.yml 中的url 为您的域名](https://raw.githubusercontent.com/Liberxue/liberxue.github.io/master/thumbnails/04.gif)
  




* [提交Issues](https://github.com/Liberxue/liberxue.github.io/issues)
 
* [发邮件](mailto:liberxue@gmail.com)
 
* [Twitter](https://twitter.com/liberxue).

